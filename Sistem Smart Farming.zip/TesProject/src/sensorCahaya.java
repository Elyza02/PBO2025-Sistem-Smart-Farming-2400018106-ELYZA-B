class sensorCahaya extends Sensor {
    public double baca() { return 800.0; }
}