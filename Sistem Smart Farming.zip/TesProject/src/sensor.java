abstract class Sensor {
    public abstract double baca();
}
