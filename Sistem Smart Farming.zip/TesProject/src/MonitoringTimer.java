import javax.swing.Timer;

public class MonitoringTimer {

    private Timer timer;

    public MonitoringTimer(Runnable task, int delay) {
        timer = new Timer(delay, e -> task.run());
    }

    public void start() {
        timer.start();
    }

    public void stop() {
        timer.stop();
    }
}
