class sensorPH extends Sensor {
    public double baca() { return 6.3; }
}