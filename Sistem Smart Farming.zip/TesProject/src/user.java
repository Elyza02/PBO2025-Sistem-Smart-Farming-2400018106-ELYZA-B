class user {
    private String username;
    private String password;

    public user(String u, String p) {
        username = u;
        password = p;
    }

    public boolean login(String u, String p) {
        return username.equals(u) && password.equals(p);
    }
}
