import javax.swing.*;
import java.awt.*;

public class Main extends JFrame {

    CardLayout card = new CardLayout();
    JPanel container = new JPanel(card);

    pompaAir pompa = new pompaAir();
    tanaman tanamanAktif;

    boolean pompaNyala = false;

    Color hijauMuda = new Color(235, 250, 235);
    Color hijauMatcha  = new Color(120, 180, 120);

    JTextArea areaMonitoring;

    public Main() {
        setTitle("Smart Farming");
        setSize(300, 430);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        container.add(loginPanel(), "login");
        container.add(dashboardUtama(), "dashboard");
        container.add(dashboardTanaman(), "tanaman");
        container.add(kontrolPompa(), "kontrol");
        container.add(catatanManual(), "catatan");

        add(container);
        card.show(container, "login");
        setVisible(true);

        MonitoringTimer monitoring = new MonitoringTimer(() -> updateMonitoring(), 700);
        monitoring.start();
    }

    /* ================= LOGIN ================= */
    JPanel loginPanel() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(30,40,30,40));
        p.setBackground(hijauMuda);

        JLabel title = new JLabel("SISTEM SMART FARMING");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Arial", Font.BOLD, 14));
        title.setForeground(hijauMatcha);

        JLabel lblUser = new JLabel("Username");
        lblUser.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextField user = new JTextField();
        user.setMaximumSize(new Dimension(200, 28));
        user.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblPass = new JLabel("Password");
        lblPass.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPasswordField pass = new JPasswordField();
        pass.setMaximumSize(new Dimension(200, 28));
        pass.setAlignmentX(Component.CENTER_ALIGNMENT);
        pass.setEchoChar((char) 0); // password terlihat

        JButton login = tombol("Login");

        p.add(title);
        p.add(Box.createVerticalStrut(15));
        p.add(lblUser);
        p.add(user);
        p.add(Box.createVerticalStrut(10));
        p.add(lblPass);
        p.add(pass);
        p.add(Box.createVerticalStrut(15));
        p.add(login);

        petani petani = new petani("admin","1234");

        login.addActionListener(e -> {
            if (petani.login(user.getText(), new String(pass.getPassword())))
                card.show(container,"dashboard");
            else
                JOptionPane.showMessageDialog(this,"Login gagal");
        });

        return p;
    }

    /* ============ DASHBOARD UTAMA ============ */
    JPanel dashboardUtama() {

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(hijauMuda);

        JLabel judul = new JLabel("SISTEM SMART FARMING", JLabel.CENTER);
        judul.setFont(new Font("Arial", Font.BOLD, 14));
        judul.setForeground(hijauMatcha);

        JPanel grid = new JPanel(new GridLayout(3,2,12,12));
        grid.setBorder(BorderFactory.createEmptyBorder(15,15,15,15));
        grid.setBackground(hijauMuda);

        JButton padi   = tombol("🌾 Padi");
        JButton tomat  = tombol("🍅 Tomat");
        JButton jagung = tombol("🌽 Jagung");
        JButton timun  = tombol("🥒 Timun");
        JButton pompaB = tombol("💧 Pompa");
        JButton catatan= tombol("📝 Catatan"); // 🔹 BARU

        padi.addActionListener(e -> pilihTanaman("Padi",30,120));
        tomat.addActionListener(e -> pilihTanaman("Tomat",20,90));
        jagung.addActionListener(e -> pilihTanaman("Jagung",25,100));
        timun.addActionListener(e -> pilihTanaman("Timun",18,75));

        pompaB.addActionListener(e -> card.show(container,"kontrol"));
        catatan.addActionListener(e -> card.show(container,"catatan"));

        grid.add(padi); grid.add(tomat);
        grid.add(jagung); grid.add(timun);
        grid.add(pompaB); grid.add(catatan);

        // 🔹 TOMBOL KELUAR DI BAWAH (MODEL KEMBALI)
        JButton keluar = tombol("⬅ Keluar");
        keluar.addActionListener(e -> {
            JOptionPane.showMessageDialog(this,
                    "Terima kasih telah menggunakan\nSistem Smart Farming");
            System.exit(0);
        });

        root.add(judul, BorderLayout.NORTH);
        root.add(grid, BorderLayout.CENTER);
        root.add(keluar, BorderLayout.SOUTH);

        return root;
    }

    void pilihTanaman(String n, int u, int p) {
        tanamanAktif = new tanaman(n,u,p);
        card.show(container,"tanaman");
    }

    /* ========= DASHBOARD TANAMAN ========= */
    JPanel dashboardTanaman() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(hijauMuda);

        // ===== JUDUL =====
        JLabel judul = new JLabel("DASHBOARD TANAMAN", JLabel.CENTER);
        judul.setFont(new Font("Arial", Font.BOLD, 13));
        judul.setForeground(hijauMatcha);
        judul.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 0));

        // ===== AREA MONITORING =====
        areaMonitoring = new JTextArea();
        areaMonitoring.setEditable(false);
        areaMonitoring.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaMonitoring.setBackground(Color.white);
        areaMonitoring.setMargin(new Insets(15, 20, 15, 20));
        areaMonitoring.setLineWrap(true);
        areaMonitoring.setWrapStyleWord(true);

        JScrollPane scroll = new JScrollPane(areaMonitoring);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // ===== TOMBOL KEMBALI =====
        JButton back = tombol("⬅ Kembali");
        back.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        back.addActionListener(e -> card.show(container,"dashboard"));

        // ===== SUSUN LAYOUT =====
        p.add(judul, BorderLayout.NORTH);
        p.add(scroll, BorderLayout.CENTER);
        p.add(back, BorderLayout.SOUTH);

        return p;
    }

    /* ========= UPDATE MONITORING ========= */
    void updateMonitoring() {
        if (tanamanAktif == null || areaMonitoring == null) return;

        double suhu = new sensorSuhu().baca();
        double kelembapan = new sensorTanah().baca();
        double ph = new sensorPH().baca();
        double cahaya = new sensorCahaya().baca();

        String status = "AMAN";
        String alasan = "Kondisi tanaman baik";

        if (kelembapan < 60) {
            status = "⚠ PERLU TINDAKAN";
            alasan = "Kelembapan tanah rendah";

            if (pompaNyala) {
                status = "AMAN";
                alasan = "Penyiraman sedang berlangsung";
            }
        }

        areaMonitoring.setText(
                "=== DASHBOARD MONITORING ===\n\n" +
                        "Tanaman      : " + tanamanAktif.getNama() + "\n" +
                        "Umur         : " + tanamanAktif.getUmur() + " hari\n" +
                        "Panen        : " + tanamanAktif.getPanen() + " hari\n\n" +
                        "Suhu         : " + suhu + " °C\n" +
                        "Kelembapan   : " + kelembapan + " %\n" +
                        "pH Tanah     : " + ph + "\n" +
                        "Cahaya       : " + cahaya + " lux\n\n" +
                        "STATUS       : " + status + "\n" +
                        "KETERANGAN   : " + alasan
        );
    }

    /* ============ KONTROL POMPA ============ */
    JPanel kontrolPompa() {
        JPanel p = new JPanel(new GridLayout(3,1,10,10));
        p.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        JButton on  = tombol("Pompa ON");
        JButton off = tombol("Pompa OFF");
        JButton back= tombol("⬅ Kembali");

        on.addActionListener(e -> {
            pompaNyala = true;
            JOptionPane.showMessageDialog(this,"Pompa air MENYALA");
        });

        off.addActionListener(e -> {
            pompaNyala = false;
            JOptionPane.showMessageDialog(this,"Pompa air MATI");
        });

        back.addActionListener(e -> card.show(container,"dashboard"));

        p.add(on); p.add(off); p.add(back);
        return p;
    }

    /* ============ CATATAN MANUAL  ============ */
    JPanel catatanManual() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(15,15,15,15));
        p.setBackground(hijauMuda);

        JLabel title = new JLabel("CATATAN MANUAL");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Arial", Font.BOLD, 13));
        title.setForeground(hijauMatcha);

        JTextArea catatan = new JTextArea(
                "Jadwal Tanam:\nTanam Padi: 3 Januari\n\n" +
                        "Pemupukan:\nPupuk Urea: Hari ke-10\n\n" +
                        "Panen:\nPanen Cabai: 25 Maret\n\n" +
                        "Catatan Hama:\nSerangan wereng pada daun"
        );
        catatan.setEditable(false);
        catatan.setFont(new Font("Arial", Font.PLAIN, 12));
        catatan.setBackground(Color.white);
        catatan.setMargin(new Insets(10,10,10,10));

        JButton back = tombol("⬅ Kembali");
        back.addActionListener(e -> card.show(container,"dashboard"));

        p.add(title);
        p.add(Box.createVerticalStrut(10));
        p.add(new JScrollPane(catatan));
        p.add(Box.createVerticalStrut(10));
        p.add(back);

        return p;
    }

    JButton tombol(String text) {
        JButton b = new JButton(text);
        b.setBackground(hijauMatcha);
        b.setForeground(Color.white);
        b.setFont(new Font("Segoe UI Emoji", Font.BOLD, 11));
        return b;
    }

    public static void main(String[] args) {
        new Main();
    }
}
