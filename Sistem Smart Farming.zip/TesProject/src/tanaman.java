class tanaman {
    private String nama;
    private int umur;
    private int panen;

    public tanaman(String n, int u, int p) {
        nama = n;
        umur = u;
        panen = p;
    }

    public String getNama() { return nama; }
    public int getUmur() { return umur; }
    public int getPanen() { return panen; }
}