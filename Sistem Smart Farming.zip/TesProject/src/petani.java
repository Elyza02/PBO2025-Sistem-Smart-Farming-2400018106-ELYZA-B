class petani extends user {
    public petani(String u, String p) {
        super(u, p);
    }
}
