class dashboard {
    public String buatTeks(
            tanaman t,
            double suhu,
            double tanah,
            double ph,
            double cahaya,
            String statusPompa
    ) {
        return
                "=== DASHBOARD MONITORING ===\n\n" +
                        "Tanaman           : " + t.getNama() + "\n" +
                        "Umur Tanaman      : " + t.getUmur() + " hari\n" +
                        "Estimasi Panen    : " + t.getPanen() + " hari\n\n" +
                        "Suhu Udara        : " + suhu + " °C\n" +
                        "Kelembapan Tanah  : " + tanah + " %\n" +
                        "pH Tanah          : " + ph + "\n" +
                        "Intensitas Cahaya : " + cahaya + " lux\n\n" +
                        "=== ANALISIS KONDISI TANAMAN ===\n" +
                        "Notifikasi: Kelembapan tanah rendah\n" +
                        statusPompa + "\n" +
                        "Notifikasi: pH tanah tidak ideal\n\n" +
                        "Jadwal penyiraman : Pagi & Sore\n" +
                        "Rekomendasi pupuk : Pupuk NPK\n" +
                        "Status hama       : Tidak ada hama terdeteksi\n";
    }
}

