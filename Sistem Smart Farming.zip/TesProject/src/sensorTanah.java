class sensorTanah extends Sensor {
    public double baca() { return 55.0; }
}