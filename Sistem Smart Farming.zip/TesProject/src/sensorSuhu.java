class sensorSuhu extends Sensor {
    public double baca() { return 30.5; }
}