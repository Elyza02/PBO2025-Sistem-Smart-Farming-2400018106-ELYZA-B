class pompaAir {
    private boolean status = false;

    public String on() {
        status = true;
        return "Pompa MENYALA";
    }

    public String off() {
        status = false;
        return "Pompa MATI";
    }

    public String getStatus() {
        return status ? "MENYALA" : "MATI";
    }
}